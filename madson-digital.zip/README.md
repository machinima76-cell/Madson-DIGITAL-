# MADSON DIGITAL — Site institucional

Site estático, responsivo e acessível para a agência **MADSON DIGITAL**. HTML, CSS e JavaScript puros, sem dependências externas, sem build obrigatório e pronto para **Cloudflare Pages**.

---

## 1. Estrutura de arquivos

```
madson-digital/
├── index.html                    Página principal (todas as seções)
├── 404.html                      Página de erro (Cloudflare Pages a serve automaticamente)
├── privacidade.html              Política de privacidade / LGPD
├── _headers                      Segurança + cache (Cloudflare Pages)
├── robots.txt
├── sitemap.xml
├── site.webmanifest
├── assets/
│   ├── css/
│   │   ├── styles.css            Design system, componentes e seções
│   │   └── demos.css             Estilos das páginas de demonstração
│   ├── js/
│   │   ├── config.js             ★ Configuração central de contato
│   │   └── main.js               Navegação, abas, validação e envio
│   ├── fonts/                    Manrope + Cormorant Garamond (woff2 locais)
│   └── img/                      Fotografias WebP, favicon, ícones e OG image
├── demos/
│   ├── industrial.html
│   ├── gastronomia.html
│   ├── automotivo.html
│   └── engenharia.html
└── tools/
    ├── build_demos.py            Gerador opcional das 4 demonstrações
    └── check_site.py             Validador estático de links, SEO e formulário
```

As quatro páginas de demonstração são **HTML estático pronto**. O script `tools/build_demos.py` existe apenas para manter o markup consistente; execute `python3 tools/build_demos.py` se quiser alterar o conteúdo das quatro de uma só vez. Ele não é necessário para publicar.

O validador `python3 tools/check_site.py` confere links internos, âncoras, arquivos referenciados, imagens, metadados, JSON-LD e consistência do formulário. Não requer bibliotecas externas.

---

## 2. Como visualizar localmente

```bash
cd madson-digital
python3 -m http.server 8080 --bind 0.0.0.0
# abra http://localhost:8080
```

Também funciona com `npx serve .` ou abrindo `index.html` diretamente (os caminhos são relativos). Não há etapa de compilação.

---

## 3. Publicação no Cloudflare Pages

**Opção A — Upload direto (mais simples)**

1. Acesse *Cloudflare Dashboard → Workers & Pages → Create → Pages → Upload assets*.
2. Envie o **conteúdo da pasta `madson-digital/`** (ou o ZIP descompactado), não a pasta que o contém.
3. Nomeie o projeto. **Build command:** deixe vazio. **Build output directory:** `/` (ou `.`).
4. Publique. `404.html`, `_headers`, `robots.txt` e `sitemap.xml` são reconhecidos automaticamente.

**Opção B — Git**

1. Suba esta pasta para um repositório.
2. Conecte o repositório no Cloudflare Pages, framework **None**, build command vazio, output directory `/`.

Domínio customizado: *Pages → projeto → Custom domains → Set up a custom domain*. O HTTPS é fornecido gratuitamente pela Cloudflare.

---

## 4. ⚠️ Ajustes obrigatórios antes de publicar

| O que | Onde | Valor atual |
|---|---|---|
| Domínio canônico | `assets/js/config.js` (`siteUrl`) | `https://madson-digital.pages.dev` |
| Domínio no HTML | `canonical`, `og:url`, `og:image`, `twitter:image` em **todos** os HTML | `https://madson-digital.pages.dev` |
| Domínio em `sitemap.xml` e `robots.txt` | raiz | `https://madson-digital.pages.dev` |
| Domínio no gerador | `SITE` em `tools/build_demos.py` | `https://madson-digital.pages.dev` |

Substitua pelo domínio real (ou pelo `*.pages.dev` que a Cloudflare atribuir ao projeto). Domínio incorreto quebra canonical, Open Graph e sitemap.

**Contato já configurado e funcional:**

- WhatsApp: `+55 47 99713-9043` → `wa.me/5547997139043`
- E-mail: `madsonsantos661@gmail.com`

Esses valores vivem em `assets/js/config.js` e, como fallback sem JavaScript, também aparecem nos `href` marcados com `data-whatsapp` / `data-email` no HTML. Se trocar número ou e-mail, atualize **ambos** os lugares. O `main.js` reescreve todos os links a partir de `config.js` quando o JavaScript está ativo.

**Redes sociais:** nenhuma URL foi informada, então **nenhum link falso foi criado**. A coluna "Redes sociais" do rodapé está oculta. Para ativá-la, edite `socials` em `assets/js/config.js`:

```js
socials: [
  { name: 'Instagram', url: 'https://instagram.com/seuperfil' },
  { name: 'LinkedIn',  url: 'https://linkedin.com/company/suaempresa' }
]
```

---

## 5. Como o formulário funciona (sem simulação)

O formulário valida no navegador (nome, telefone com DDD, e-mail, tipo de projeto, descrição mínima e consentimento LGPD) e entrega a mensagem por um **canal real**, escolhido pelo visitante:

- **Enviar pelo WhatsApp** → abre `https://wa.me/...?text=...` com a mensagem completa já preenchida, em nova aba.
- **Enviar por e-mail** → abre `mailto:...?subject=...&body=...` no aplicativo de e-mail do visitante.

O visitante confirma o envio no aplicativo. Não há `fetch()`, não há backend, não há banco de dados e não há tela de "mensagem enviada" fingindo sucesso. Por isso não é necessário nenhum serviço pago ou chave de API. Se no futuro quiser receber os dados automaticamente em um servidor, substitua `initForm()` em `assets/js/main.js` por uma Cloudflare Pages Function — o restante do site não muda.

Os links de planos e serviços (`data-prefill`) levam ao formulário e **pré-selecionam** a opção correspondente no campo "Tipo de projeto". As abas de planos são navegáveis por teclado (setas, Home e End).

---

## 6. Decisões de projeto

- **Identidade:** preto `#101116`, grafite `#20232B`, dourado `#B99B65`, off-white `#E8E5DF`, branco. Tipografia local (Manrope + Cormorant Garamond). Fotografia realista; sem robôs, circuitos, gradientes neon ou estética genérica de IA.
- **Sem dados inventados:** não há depoimentos, clientes, números de resultados ou preços. Planos exibem "Sob consulta". As quatro demonstrações estão identificadas como conteúdo fictício.
- **Acessibilidade:** link "pular para o conteúdo", foco visível, `aria-*` em menu/abas/formulário, mensagens de erro associadas via `aria-describedby`, `role="status"` para feedback, contraste revisado, `prefers-reduced-motion`, navegação completa por teclado e textos alternativos.
- **SEO:** `lang="pt-BR"`, título/descrição/canonical/Open Graph/Twitter por página, JSON-LD (`Organization` + `WebPage`), hierarquia de cabeçalhos, `robots.txt`, `sitemap.xml` e URLs amigáveis.
- **Performance:** fontes `woff2` locais com `preload`, imagens WebP otimizadas com `srcset` no hero e `loading="lazy"`/`decoding="async"` no restante, dimensões declaradas para evitar CLS, CSS/JS enxutos e sem bibliotecas de terceiros.
- **Privacidade:** sem cookies, analytics, pixels ou scripts externos. Veja `privacidade.html`.
- **Custo:** apenas Cloudflare Pages (plano gratuito). Domínio, se houver, é contratado à parte pelo cliente.

---

## 7. Verificação rápida antes do deploy

Execute `python3 tools/check_site.py` (deve terminar com `OK`). Em seguida:

- [ ] Substituir o domínio nos arquivos listados na seção 4
- [ ] Conferir número de WhatsApp e e-mail em `config.js` e nos `href`
- [ ] Adicionar redes sociais em `config.js` (ou manter a coluna oculta)
- [ ] Testar o formulário nos dois modos de envio
- [ ] Testar links do menu, das quatro demonstrações e da página 404
- [ ] Verificar no celular, tablet e desktop
